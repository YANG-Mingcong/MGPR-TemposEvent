#include "MyObjectOSCCommandPool.h"

MyObjectOSCCommandPool::MyObjectOSCCommandPool(QObject *parent) : QObject(parent)
{

}
