#include "MyGloble.h"

MyGloble::MyGloble()
{

}

//GLOBAL Variable
QString MyGloble::G_IP_MIL = "169.254.160.141";
QString MyGloble::G_IP_VV1 = "169.254.65.77";
QString MyGloble::G_IP_VV2 = "169.254.159.128";

