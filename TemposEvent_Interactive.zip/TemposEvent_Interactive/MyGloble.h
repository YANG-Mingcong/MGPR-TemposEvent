#ifndef MYGLOBLE_H
#define MYGLOBLE_H

#include <QString>
#include <QFont>
#include <QLabel>

class MyGloble
{
public:
    MyGloble();
    //Globel variables
    static QString G_IP_MIL;
    static QString G_IP_VV1;
    static QString G_IP_VV2;


};

#endif // MYGLOBLE_H
