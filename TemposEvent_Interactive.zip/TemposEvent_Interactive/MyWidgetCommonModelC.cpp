#include "MyWidgetCommonModelC.h"

MyWidgetCommonModelC::MyWidgetCommonModelC(QWidget *parent) : QWidget(parent)
{

}
