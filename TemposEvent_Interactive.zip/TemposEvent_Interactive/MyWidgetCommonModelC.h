#ifndef MYWIDGETCOMMONMODELC_H
#define MYWIDGETCOMMONMODELC_H

#include <QWidget>

class MyWidgetCommonModelC : public QWidget
{
    Q_OBJECT
public:
    explicit MyWidgetCommonModelC(QWidget *parent = nullptr);

signals:

};

#endif // MYWIDGETCOMMONMODELC_H
